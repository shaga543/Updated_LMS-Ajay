import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment-modal',
  templateUrl: './payment-modal.component.html',
  styleUrls: ['./payment-modal.component.css']
})
export class PaymentModalComponent {

  constructor(private router: Router) {}

  // Simulate the payment process
  pay(paymentMethod: string): void {
    console.log('Payment method selected:', paymentMethod);

    // Simulate successful payment and navigate back to Issue Book
    setTimeout(() => {
      alert('Payment Successful!');
      this.router.navigate(['/issue-book']);  // Navigate to the Issue Book page after success
    }, 2000); // Simulate processing delay
  }
}
