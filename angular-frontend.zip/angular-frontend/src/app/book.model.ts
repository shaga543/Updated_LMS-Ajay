export interface Book {
    id: number;
    title: string;
    author: string;
    genre: string;
    isbn: string;
    available: boolean;
  }