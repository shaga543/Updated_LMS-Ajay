package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.example.demo.model.Issue;

public interface IssueRepository extends JpaRepository<Issue, Long> {
    List<Issue> findByEmployeeId(Long employeeId);
    List<Issue> findByBookId(Long bookId);
}